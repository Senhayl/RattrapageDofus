# Handoff : Back from AFK — DA « Krosmoz, nuit »

## Overview
Nouvelle direction artistique pour le site Astro **Back from AFK** (repo `DofusRattrapage`) : accueil et page de classe. Le contenu, la structure, les textes (`src/i18n/ui.ts`) et la logique ne changent pas : seul le style change. Le style s'inspire d'un hero avec une illustration peinte en plein écran, un titre centré en capitales, une nav blanche discrète et un bouton pilule blanc, transposés dans une ambiance nuit étoilée.

## About the Design Files
`Back from AFK v2.dc.html` est une **maquette de référence en HTML**, pas du code à copier. La tâche consiste à **recréer ce design dans le code Astro existant** : `src/styles/global.css` (variables), `src/layouts/Base.astro`, `HomePage.astro`, `Preview.astro`, `Picker.astro`, `BalanceBar.astro`, `ClassPage.astro`, `SpellChanges.astro`. Les composants, les filtres JS, le Picker, le fetch de l'aperçu et l'i18n restent tels quels. Les données de la maquette sont des exemples.

## Fidelity
**High-fidelity** : couleurs, typo, espacements et bordures sont définitifs. La maquette est à 1280 px de large. Le site reste fluide : garde `--gutter`, les `clamp()` et les media queries existants (960 px pour le hero, 1000 px pour la colonne pub).

## Principes
- Pas de dégradé décoratif, pas de halo, pas d'ombre portée sur les cartes. Uniquement des aplats et des filets de 1 px.
- Un seul accent : beige doré `#e9d9b0`.
- Le « réalisme » vient d'une **illustration peinte** en fond du hero (asset à fournir), pas du CSS.
- Mode sombre uniquement : supprimer le bloc `@media (prefers-color-scheme: light)`, ou bien le décliner plus tard.

## Design Tokens (remplacent `:root` de global.css)
```
--bg:        #0b0d14   fond de page
--bg-hero:   #0d1124   fond du hero tant qu'aucune image n'est chargée
--surface:   #12141d   carte d'aperçu
--line:      #23263a   filets, bordures
--line-soft: #1c1f2e   bordure du footer
--text:      #eceae4
--text-2:    #d6d5dc   chips, filtres
--text-3:    #b5b6c2   résumé
--muted:     #9a9caa   labels, légendes
--faint:     #6f7184   valeurs barrées, flèches, footer
--accent:    #e9d9b0   (remplace --gold) choix du Picker, liens, survol du bouton
--accent-ink:#0b0d14
--up:        #7fbf9a
--nerf:      #d9877a
--mixte:     #d8b46a
--neutre:    #2e3247   (index : #4a4e66)
```
Éléments (pastilles, si conservées) : terre `#d9a05a`, feu `#ff7a5a`, eau `#6ab8ff`, air `#6fe08a`, neutre `#8187b3`. Dans la maquette, l'élément est écrit dans le label (« Effet · Terre ») à la place de la pastille. Les deux options sont acceptables.

Radius : 999px (pilules), 18px (carte d'aperçu), 12px (cadre pub), 2px (barres). Aucune ombre.

## Typographie
- **Outfit** (300/400/500/600) : corps, nav, UI. Corps : 17px/1.55, poids 400.
- **Instrument Serif** (400, normal et italique) : choix du Picker, h1 de classe, h2 de section.
- À installer via `@fontsource/outfit` et `@fontsource/instrument-serif`, à la place de Bricolage et Figtree.

Échelle :
- Titre du hero (Picker, mode hero) : Outfit 500, 70px/1.06, uppercase, letter-spacing -0.01em, blanc, `text-wrap: balance`. Les `<select>` sont en Instrument Serif italique, 1.18em, sans uppercase, couleur `--accent`, sans soulignement. Chevron : ▼ en Outfit 300, 0.3em, relevé de 0.35em.
- Surtitre du hero : 14px, uppercase, letter-spacing .14em, blanc à 70 %. Texte : « 19 classes · 8 versions comparées », à rendre dynamique et à ajouter à ui.ts.
- Lede : Outfit 300, 19px/1.55, blanc à 85 %, max 46ch.
- h2 de section : Instrument Serif 34px/1.1, blanc. La partie « depuis la X » est en italique `--accent`.
- h1 de classe : Instrument Serif 112px/0.95, blanc (clamp conseillé : `clamp(3.5rem, 10vw, 7rem)`).
- Picker compact : Outfit 300, 21px. Les selects sont en `--accent` avec `border-bottom: 1px solid rgba(233,217,176,.6)`.
- h3 de sort : Outfit 500, 22px, blanc.
- Tags de verdict : texte seul, sans pilule. Outfit 500, 11–11.5px, uppercase, letter-spacing .1em, couleur up/nerf/mixte.

## Screens

### 1. Base.astro (header et footer)
- Le header est **posé sur le hero**, en absolu ou dans le hero, sans bordure. Padding 28px 40px, max-width 1180px.
- Marque : « Back from AFK » en Outfit 500 20px blanc, et brandSub en 300 blanc à 70 %, gap 8px, alignés sur la baseline.
- À droite (gap 28px, 14.5px, blanc à 80 %) : le texte « Données à jour… », puis les langues en texte simple, gap 18px. La langue courante est en blanc et en 500.
- Footer : `border-top: 1px solid --line-soft`, padding 30px 0 48px, 14px `--faint`, max 68ch.
- `.wrap` passe à max-width 1180px.

### 2. Accueil (HomePage, Picker hero, Preview)
- **Hero** : hauteur 800px (`min-height: min(800px, 100svh)` conseillé), en pleine largeur. Couches :
  1. L'illustration en `object-fit: cover`.
  2. Un scrim `linear-gradient(180deg, rgba(6,7,12,.55) 0%, rgba(6,7,12,0) 20%, rgba(6,7,12,0) 62%, #0b0d14 100%)`.
  3. Le contenu centré, en colonne, gap 28px, padding-top 170px, max-width 1060px : surtitre, Picker, lede, bouton.
- **Bouton CTA** : fond `#fff`, texte `#0b0d14`, Outfit 500 16px, padding 16px 28px, radius 999px. Au survol, le fond passe à `--accent`.
- **Preview** : remonte de 110px sur le bas du hero (`margin-top: -110px`), max-width 820px, centré. Fond `--surface`, bordure 1px `--line`, radius 18px, padding 26px 30px 22px.
  - En-tête en flex space-between : titre (500, 20px) et lien « Voir les N sorts concernés » (`--accent`, souligné en 1px, offset 4px).
  - BalanceBar compacte : hauteur 4px, gap 2px, radius 2px. Légende 13.5px `--muted`, chiffres en 500 `--text`, `white-space: nowrap` par item.
  - Lignes en **grille de 2 colonnes** (column-gap 32px). Chaque ligne : padding 14px 0, `border-top --line`. Ligne 1 : nom du sort (500, 16px), avec le tag de verdict aligné à droite. Ligne 2 : label 13.5px `--muted`. Ligne 3 : `<del>` `--faint`, → , valeur après en blanc.
- **Liste des classes** : padding-top 96px. En-tête : h2, plus une légende où chaque item est un trait de 12×3px. Grille de 4 colonnes (column-gap 36px), à garder en `auto-fill minmax(240px)` pour le responsive. Chaque item : padding 16px 0, `border-top --line`. Nom en Outfit 400 19px, compteur 15px `--muted`. Barre de 3px de haut, sans radius. Au survol : `border-top-color: --accent`.

### 3. Page de classe (ClassPage, Picker compact, BalanceBar, SpellChanges)
- **Bandeau** de 420px, avec le même système image et scrim : `rgba(6,7,12,.55) 0%` → `0 35%` → `#0b0d14 100%`. Le contenu est aligné à gauche, padding-top 120px : h1, puis Picker compact (gap 12px).
- **Layout** : grille `minmax(0,1fr) 300px`, gap 56px, padding 28px 40px 88px. La colonne pub est un AdSlot de 600px, avec en dev un cadre en pointillés 1px `--line` et radius 12px.
- Résumé : 300, `--text-3`, max 62ch. Les nombres forts sont en blanc 500.
- BalanceBar : max-width 640px, margin-top 18px, hauteur 4px.
- Index (chips) : margin-top 22px, gap 6px. Chaque chip : padding 5px 12px, bordure 1px `--line`, radius 999px, 13.5px `--text-2`, avec un point de 6px de la couleur du verdict. Au survol, la bordure passe à `--faint`.
- **Filtres** (sticky) : margin-top 28px, padding 14px 0, `border-top` et `border-bottom` `--line`, fond `--bg`, 15px. Le segmented control a une bordure 1px `--line`, radius 999px et 2px de padding. L'option active a un fond `--text` et un texte `--bg`. Cases à cocher : `accent-color: var(--accent)`.
- h2 « Sorts modifiés » : Instrument Serif 34px, margin 44px 0 8px.
- **SpellChanges** : padding 24px 0 22px, `border-top --line`. **Supprimer le liseré gauche** (`::before`). L'en-tête aligne sur la baseline le h3 (500, 22px, blanc) et le tag de verdict (texte seul). Rangées : grille `11.5rem 1fr`, gap 16px, 8px entre les rangées. Label 15px `--muted`. Valeur : `<del>` `--faint`, flèche, valeur après en blanc, delta `--faint`, puis mini-tag texte. `:target h3` passe en `--accent`.
- « Nouveaux sorts », « Sorts retirés » et « Revenu à un autre moment ? » suivent le même système : h2 en serif, items séparés par `border-top --line`, liens en `--muted` qui passent en blanc au survol.

## Interactions & Behavior
Aucun changement : Picker (fit des selects, submit, navigation au change en mode compact), mise à jour de l'aperçu via `picker:change`, filtres JS et ancres de l'index. Les seuls états à styler sont les survols indiqués plus haut. Transitions de 150 ms, `ease`. Garder `prefers-reduced-motion` et `:focus-visible` (outline 3px `--accent`).

## Assets
- **À fournir : une illustration peinte** de ciel étoilé, idéalement un paysage du Krosmoz de nuit, au moins 2560×1600, en WebP/AVIF. Elle sert au hero de l'accueil et au bandeau de la page de classe (un recadrage, ou une image par classe plus tard). Aucune illustration n'est générée ici. À placer dans `public/` ou `src/assets/` (avec `astro:assets` pour `srcset`). Tant qu'elle n'existe pas, le fond `--bg-hero` uni suffit.
- Vérifier les droits avant d'utiliser des visuels officiels d'Ankama (voir le README du repo, conditions pour les sites de fans).
- Favicon : à recolorer avec `--bg` et `--accent`.

## Files
- `Back from AFK v2.dc.html` : maquette, avec 3a (accueil) et 3b (page de classe).
- `image-slot.js` : uniquement pour la maquette (placeholder d'image), à ne pas porter.
